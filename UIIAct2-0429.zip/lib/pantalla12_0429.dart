import 'package:flutter/material.dart';

class Pantalla12_0429 extends StatelessWidget {
  const Pantalla12_0429({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pantalla12 0429"),
        backgroundColor: Color(0xfffca8cb),
      ),
      backgroundColor: Color(0xfffcd4e5),
      body: Container(
        color: Color(0xffff8abb),
        child: Text(
          'David Arellano 0429',
          style: TextStyle(fontSize: 31, color: Color(0xffffffff)),
        ),
      ),
    );
  } // fin widget
} //fin pantalla 5
