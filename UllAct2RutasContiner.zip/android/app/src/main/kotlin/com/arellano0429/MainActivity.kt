package com.arellano0429

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
