//Pantalla1_0429

import 'package:flutter/material.dart';

class Pantalla1_0429 extends StatelessWidget {
  const Pantalla1_0429({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pantalla1 0429'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          children: [
            Text(
              "David Arellano Atrrizando",
              style: TextStyle(fontSize: 32, color: Colors.deepPurple.shade300),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                margin: EdgeInsets.only(top: 20),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.deepPurple.shade700,
                    width: 10,
                  ),
                ),
                width: 280,
                height: 280,
                alignment: Alignment.center,
                child: Text(
                  'DA',
                  style: TextStyle(
                    fontSize: 180,
                    color: Colors.deepPurple.shade700,
                  ),
                ),
              ),
            ),
            Text(
              "Mat. 21308051280429",
              style: TextStyle(fontSize: 32, color: Colors.deepPurple.shade300),
            ),
          ],
        ),
      ),
    );
    ();
  }
}
