//Pantalla2_0429

import 'package:flutter/material.dart';

class Pantalla2_0429 extends StatelessWidget {
  const Pantalla2_0429({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pantalla 2 0429"),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Text("Pantalla 2"),
      ),
    );
  }
}
