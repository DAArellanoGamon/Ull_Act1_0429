//PantallaIni_0429

import 'package:flutter/material.dart';

class PantallaIni_0429 extends StatelessWidget {
  const PantallaIni_0429({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Ferreteria Arellano 0429",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color(0xffff2d2d),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFFEFEBE9)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFFD1C4E9)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFFB39DDB)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF9575CD)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF7E57C2)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF673AB7)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF5E35B1)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF512DA8)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF4527A0)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF311B92)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0429');
              },
              child: Text(
                "Aterrizando P1",
                style: TextStyle(color: Color(0xff000000)),
              ),
            ),
          ], // fin de nino
        ),
      ),
    );
  } //fin widgets
} //fin app
